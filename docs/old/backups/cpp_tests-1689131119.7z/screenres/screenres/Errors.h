#pragma once
#ifndef ERRORS_H
#define ERRORS_H
#include <Windows.h>
const LPWSTR GetLastErrorMessage();
#endif // !ERRORS_H


