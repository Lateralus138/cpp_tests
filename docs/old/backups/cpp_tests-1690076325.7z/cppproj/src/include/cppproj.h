#ifndef CPPPROJ_H
#define CPPPROJ_H
#include "SignalHandler.h"
#include "Directories.h"
#include "Files.h"
#include "Functions.h"
#include "ArgParser.h"
#include "Globals.h"
#include <filesystem>
#include <iostream>
#include <vector>
#endif
