#ifndef FILES_H
#define FILES_H
#include "Directories.h"
class Files: public Directories {};
extern Files files;
#endif // FILES_H
