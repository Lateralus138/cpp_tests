# CPP Tests

<sub>via [`CodeFactor`](https://www.codefactor.io/) and [`ShieldsIO`](https://shields.io/)</sub>

## What, What

Nothing to see here, various `CPP` tests for CodeFactor and otherwise. You'll probably see a bunch of nonsense.

## Current CPP Code-Factor Grade

<sub>Only `.cpp` and possible regular `file`s (?) are parsed here as per [`.gitattributes`](./.gitattributes).</sub>

![Current File](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/Lateralus138/cpp_tests/master/docs/json/file.json)![Current CPP](https://img.shields.io/codefactor/grade/github/Lateralus138/cpp_tests/master?style=for-the-badge&labelColor=1d1d1d&label=Code%20Factor%20Grade)