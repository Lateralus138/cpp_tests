#ifndef PIPE_H
#define PIPE_H
#include <vector>
#include <string>
void VectorFromPipe(std::vector<std::string> &vector, bool skipEmpty);
#endif // PIPE_H
