#pragma once
#ifndef SAFETY_H
#define SAFETY_H
namespace Safety
{
  extern void SystemCheck();
};
#endif
